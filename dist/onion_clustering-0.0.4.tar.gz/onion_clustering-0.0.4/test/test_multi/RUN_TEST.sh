#!/bin/bash

python3 ../../src/onion_clustering/main_2d.py

rm -f output_figures/*_Fig*.png
rm -f signal_with_labels.dat
rm -r output_figures
